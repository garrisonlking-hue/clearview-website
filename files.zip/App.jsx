import { useState, useEffect } from 'react'
import { supabase } from './supabase'

// ── Design tokens (matched to CRM) ─────────────────────────────
const NAVY = '#0f1c3f'
const NAVY_DARK = '#0a1430'
const BLUE = '#2563eb'
const BLUE_LIGHT = '#eff6ff'
const GREEN = '#16a34a'
const ORANGE = '#f97316'
const WHITE = '#ffffff'
const GRAY50 = '#f8fafc'
const GRAY100 = '#f1f5f9'
const GRAY200 = '#e2e8f0'
const GRAY500 = '#64748b'
const GRAY700 = '#334155'
const GRAY900 = '#0f172a'

const PHONE = '(860) 966-3149'
const PHONE_TEL = 'tel:+18609663149'
const EMAIL = 'hello@clearviewwindowsct.com' // change as needed

const SERVICES = [
  { id: 'windows', icon: '🪟', title: 'Window Cleaning', desc: 'Crystal-clear interior & exterior window cleaning. Streak-free guaranteed.', features: ['Inside + outside', 'Screens included', 'Sills wiped down'] },
  { id: 'gutters', icon: '🍂', title: 'Gutter Cleaning', desc: 'Full gutter cleanout and downspout flush. Prevents costly water damage.', features: ['Hand-cleaned', 'Debris hauled away', 'Downspout flush'] },
  { id: 'screens', icon: '🧽', title: 'Screen Cleaning', desc: 'Pull, wash, and reinstall every window screen. Like new again.', features: ['Deep washed', 'Frames detailed', 'Tracks cleaned'] },
  { id: 'solar', icon: '☀️', title: 'Solar Panel Cleaning', desc: 'Restore panel efficiency by up to 25% with professional cleaning.', features: ['Safe deionized water', 'No streaks or residue', 'Boost energy output'] },
  { id: 'pressure', icon: '💦', title: 'Pressure Washing', desc: 'Siding, driveways, patios, walkways — restored to fresh.', features: ['Surface-safe', 'Eco-friendly soap', 'Soft & power wash'] },
  { id: 'hardwater', icon: '✨', title: 'Hard Water Stain Removal', desc: 'Remove mineral stains that regular cleaning can\'t touch.', features: ['Specialty solutions', 'Restores glass clarity', 'Long-lasting result'] },
]

const TOWNS = ['Coventry', 'Mansfield', 'Storrs', 'Tolland', 'Vernon', 'Bolton', 'Andover', 'Columbia', 'Willimantic', 'Ellington']

const REVIEWS = [
  // Placeholder reviews — replace with real Google reviews when available
  { name: 'Sarah M.', town: 'Coventry, CT', text: 'Garrison and his team did our whole house — inside and out. Looks brand new. Will absolutely book again.', rating: 5 },
  { name: 'Mike R.', town: 'Tolland, CT', text: 'Showed up exactly on time. Professional, fast, and the windows have never looked better. Fair price too.', rating: 5 },
  { name: 'Jennifer L.', town: 'Mansfield, CT', text: 'They cleaned years of buildup off our solar panels. Energy production noticeably went up. Highly recommend.', rating: 5 },
]

// ── Reusable components ────────────────────────────────────────
function Btn({ children, onClick, primary, large, href, style }) {
  const baseStyle = {
    display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: 8,
    background: primary ? BLUE : 'transparent',
    color: primary ? WHITE : NAVY,
    border: primary ? 'none' : `2px solid ${NAVY}`,
    borderRadius: 12,
    padding: large ? '14px 28px' : '10px 20px',
    fontSize: large ? 16 : 14,
    fontWeight: 700,
    cursor: 'pointer',
    transition: 'all 0.2s ease',
    boxShadow: primary ? '0 4px 14px rgba(37,99,235,0.35)' : 'none',
    letterSpacing: '-0.01em',
    ...style
  }
  const hoverStyle = e => {
    e.currentTarget.style.transform = 'translateY(-2px)'
    e.currentTarget.style.boxShadow = primary ? '0 8px 24px rgba(37,99,235,0.45)' : '0 4px 12px rgba(0,0,0,0.1)'
  }
  const leaveStyle = e => {
    e.currentTarget.style.transform = 'translateY(0)'
    e.currentTarget.style.boxShadow = primary ? '0 4px 14px rgba(37,99,235,0.35)' : 'none'
  }
  if (href) return <a href={href} style={baseStyle} onMouseEnter={hoverStyle} onMouseLeave={leaveStyle}>{children}</a>
  return <button onClick={onClick} style={baseStyle} onMouseEnter={hoverStyle} onMouseLeave={leaveStyle}>{children}</button>
}

function Section({ children, bg, style }) {
  return <section style={{ padding: '5rem 1.5rem', background: bg || WHITE, ...style }}>
    <div style={{ maxWidth: 1200, margin: '0 auto' }}>{children}</div>
  </section>
}

function SectionTitle({ eyebrow, title, subtitle, center }) {
  return (
    <div style={{ marginBottom: '3rem', textAlign: center ? 'center' : 'left', maxWidth: center ? 720 : 'none', margin: center ? '0 auto 3rem' : '0 0 3rem' }}>
      {eyebrow && <div style={{ display: 'inline-block', background: BLUE_LIGHT, color: BLUE, padding: '6px 14px', borderRadius: 20, fontSize: 12, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: 14 }}>{eyebrow}</div>}
      <h2 style={{ fontFamily: "'Playfair Display', Georgia, serif", fontSize: 'clamp(28px, 4vw, 44px)', fontWeight: 800, color: NAVY, lineHeight: 1.15, letterSpacing: '-0.02em', marginBottom: subtitle ? 14 : 0 }}>{title}</h2>
      {subtitle && <p style={{ fontSize: 17, color: GRAY500, lineHeight: 1.6 }}>{subtitle}</p>}
    </div>
  )
}

// ── Navigation ─────────────────────────────────────────────────
function Nav({ onCTA }) {
  const [scrolled, setScrolled] = useState(false)
  const [mobileOpen, setMobileOpen] = useState(false)

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 40)
    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  return (
    <nav style={{
      position: 'fixed', top: 0, left: 0, right: 0, zIndex: 100,
      background: scrolled ? 'rgba(255,255,255,0.95)' : 'transparent',
      backdropFilter: scrolled ? 'blur(12px)' : 'none',
      borderBottom: scrolled ? `1px solid ${GRAY200}` : '1px solid transparent',
      transition: 'all 0.3s ease',
      padding: '14px 1.5rem'
    }}>
      <div style={{ maxWidth: 1200, margin: '0 auto', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <a href="#top" style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <div style={{ width: 38, height: 38, background: `linear-gradient(135deg, #1d4ed8 0%, #3b82f6 100%)`, borderRadius: 10, display: 'flex', alignItems: 'center', justifyContent: 'center', boxShadow: '0 4px 12px rgba(37,99,235,0.4)' }}>
            <svg width="20" height="20" viewBox="0 0 24 24" fill="white"><path d="M3 13h1v7c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2v-7h1c.55 0 1-.45 1-1s-.45-1-1-1L12 2 2 11c-.55 0-1 .45-1 1s.45 1 1 1z"/></svg>
          </div>
          <div>
            <div style={{ fontSize: 17, fontWeight: 800, color: scrolled ? NAVY : WHITE, letterSpacing: '-0.02em', transition: 'color 0.3s' }}>ClearView</div>
            <div style={{ fontSize: 10, color: scrolled ? GRAY500 : 'rgba(255,255,255,0.7)', textTransform: 'uppercase', letterSpacing: '0.1em', marginTop: -2, transition: 'color 0.3s' }}>Windows · CT</div>
          </div>
        </a>

        <div style={{ display: window.innerWidth >= 768 ? 'flex' : 'none', gap: 32, alignItems: 'center' }}>
          {['Services', 'Gallery', 'Reviews', 'Service Area'].map(item => (
            <a key={item} href={`#${item.toLowerCase().replace(' ', '-')}`} style={{ fontSize: 14, fontWeight: 600, color: scrolled ? GRAY700 : 'rgba(255,255,255,0.9)', transition: 'color 0.2s' }}>{item}</a>
          ))}
          <a href={PHONE_TEL} style={{ fontSize: 14, fontWeight: 700, color: scrolled ? NAVY : WHITE }}>📞 {PHONE}</a>
          <Btn primary onClick={onCTA}>Get Free Quote</Btn>
        </div>

        {/* Mobile menu button */}
        <button onClick={() => setMobileOpen(!mobileOpen)} style={{ display: window.innerWidth < 768 ? 'flex' : 'none', background: 'none', border: 'none', padding: 8, flexDirection: 'column', gap: 4 }}>
          <div style={{ width: 22, height: 2, background: scrolled ? NAVY : WHITE }} />
          <div style={{ width: 22, height: 2, background: scrolled ? NAVY : WHITE }} />
          <div style={{ width: 22, height: 2, background: scrolled ? NAVY : WHITE }} />
        </button>
      </div>

      {/* Mobile menu */}
      {mobileOpen && window.innerWidth < 768 && (
        <div style={{ background: WHITE, padding: '1rem 1.5rem', borderTop: `1px solid ${GRAY200}`, display: 'flex', flexDirection: 'column', gap: 16, marginTop: 14 }}>
          {['Services', 'Gallery', 'Reviews', 'Service Area'].map(item => (
            <a key={item} href={`#${item.toLowerCase().replace(' ', '-')}`} onClick={() => setMobileOpen(false)} style={{ fontSize: 16, fontWeight: 600, color: GRAY700 }}>{item}</a>
          ))}
          <a href={PHONE_TEL} style={{ fontSize: 16, fontWeight: 700, color: NAVY }}>📞 {PHONE}</a>
          <Btn primary onClick={() => { onCTA(); setMobileOpen(false) }}>Get Free Quote</Btn>
        </div>
      )}
    </nav>
  )
}

// ── Hero ───────────────────────────────────────────────────────
function Hero({ onCTA }) {
  return (
    <section id="top" style={{
      minHeight: '100vh',
      background: `linear-gradient(135deg, ${NAVY_DARK} 0%, ${NAVY} 50%, #1e3a6e 100%)`,
      color: WHITE,
      display: 'flex',
      alignItems: 'center',
      padding: '120px 1.5rem 80px',
      position: 'relative',
      overflow: 'hidden'
    }}>
      {/* Decorative orbs */}
      <div style={{ position: 'absolute', top: '-15%', right: '-10%', width: '50vw', height: '50vw', borderRadius: '50%', background: 'rgba(59,130,246,0.15)', filter: 'blur(80px)', pointerEvents: 'none' }} />
      <div style={{ position: 'absolute', bottom: '-20%', left: '-10%', width: '40vw', height: '40vw', borderRadius: '50%', background: 'rgba(37,99,235,0.10)', filter: 'blur(80px)', pointerEvents: 'none' }} />

      <div style={{ maxWidth: 1200, margin: '0 auto', display: 'grid', gridTemplateColumns: window.innerWidth >= 968 ? '1.1fr 0.9fr' : '1fr', gap: '3rem', alignItems: 'center', position: 'relative', zIndex: 2, width: '100%' }}>
        <div className="fade-in-up">
          <div style={{ display: 'inline-flex', alignItems: 'center', gap: 8, background: 'rgba(255,255,255,0.1)', backdropFilter: 'blur(10px)', border: '1px solid rgba(255,255,255,0.15)', padding: '8px 16px', borderRadius: 30, fontSize: 13, fontWeight: 600, marginBottom: 24, color: 'rgba(255,255,255,0.95)' }}>
            ✨ Serving Coventry, CT & 8 surrounding towns
          </div>

          <h1 style={{ fontFamily: "'Playfair Display', Georgia, serif", fontSize: 'clamp(40px, 6vw, 68px)', fontWeight: 800, lineHeight: 1.05, letterSpacing: '-0.03em', marginBottom: 20 }}>
            Crystal-clear windows.<br />
            <span style={{ background: 'linear-gradient(135deg, #93c5fd 0%, #60a5fa 100%)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text' }}>Zero hassle.</span>
          </h1>

          <p style={{ fontSize: 19, lineHeight: 1.6, color: 'rgba(255,255,255,0.75)', marginBottom: 36, maxWidth: 540 }}>
            Connecticut's trusted local window cleaning service. We handle the interior, exterior, gutters, screens, and everything in between — so you don't have to.
          </p>

          <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap', marginBottom: 40 }}>
            <Btn primary large onClick={onCTA}>Get Free Quote →</Btn>
            <Btn large href={PHONE_TEL} style={{ background: 'rgba(255,255,255,0.08)', border: '2px solid rgba(255,255,255,0.2)', color: WHITE, backdropFilter: 'blur(10px)' }}>📞 Call {PHONE}</Btn>
          </div>

          {/* Trust signals */}
          <div style={{ display: 'flex', gap: 28, flexWrap: 'wrap', paddingTop: 28, borderTop: '1px solid rgba(255,255,255,0.1)' }}>
            {[
              { num: '500+', label: 'Windows cleaned' },
              { num: '5.0★', label: 'Customer rating' },
              { num: '100%', label: 'Satisfaction guarantee' },
            ].map(s => (
              <div key={s.label}>
                <div style={{ fontSize: 28, fontWeight: 800, fontFamily: "'Playfair Display', Georgia, serif", color: WHITE, lineHeight: 1 }}>{s.num}</div>
                <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.5)', fontWeight: 500, marginTop: 4, letterSpacing: '0.04em' }}>{s.label}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Hero visual */}
        <div className="fade-in-up" style={{ position: 'relative', animationDelay: '0.2s' }}>
          <div style={{ position: 'relative', borderRadius: 24, overflow: 'hidden', boxShadow: '0 30px 80px rgba(0,0,0,0.5)' }}>
            <div style={{ aspectRatio: '4/5', background: `linear-gradient(135deg, #1e3a6e 0%, #2563eb 50%, #60a5fa 100%)`, position: 'relative' }}>
              {/* Window grid graphic */}
              <div style={{ position: 'absolute', inset: '8%', display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gridTemplateRows: 'repeat(3, 1fr)', gap: 8 }}>
                {[...Array(9)].map((_, i) => (
                  <div key={i} style={{
                    background: 'linear-gradient(135deg, rgba(255,255,255,0.45) 0%, rgba(255,255,255,0.1) 100%)',
                    borderRadius: 4,
                    border: '2px solid rgba(255,255,255,0.3)',
                    position: 'relative',
                    overflow: 'hidden'
                  }}>
                    {/* Shine effect */}
                    <div style={{
                      position: 'absolute',
                      top: 0, left: 0, right: 0, bottom: 0,
                      background: 'linear-gradient(45deg, transparent 30%, rgba(255,255,255,0.7) 50%, transparent 70%)',
                      backgroundSize: '200% 200%',
                      animation: `shimmer 3s ease-in-out ${i * 0.15}s infinite`
                    }} />
                  </div>
                ))}
              </div>
              {/* Squeegee icon overlay */}
              <div style={{ position: 'absolute', bottom: 24, right: 24, background: WHITE, borderRadius: 14, padding: '14px 18px', boxShadow: '0 12px 32px rgba(0,0,0,0.25)' }}>
                <div style={{ fontSize: 11, color: GRAY500, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 2 }}>Today's job</div>
                <div style={{ fontSize: 16, fontWeight: 800, color: NAVY }}>28 windows ✨</div>
              </div>
            </div>
          </div>
          {/* Floating badge */}
          <div style={{ position: 'absolute', top: -20, left: -20, background: WHITE, borderRadius: 14, padding: '12px 16px', boxShadow: '0 12px 32px rgba(0,0,0,0.2)', display: 'flex', alignItems: 'center', gap: 10 }}>
            <div style={{ fontSize: 28 }}>⭐</div>
            <div>
              <div style={{ fontSize: 14, fontWeight: 800, color: NAVY }}>5-Star Rated</div>
              <div style={{ fontSize: 11, color: GRAY500, fontWeight: 500 }}>Local Coventry team</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

// ── Services ───────────────────────────────────────────────────
function Services({ onCTA }) {
  return (
    <Section bg={WHITE} style={{ padding: '6rem 1.5rem' }}>
      <div id="services" />
      <SectionTitle
        eyebrow="What we do"
        title="Six services. One trusted crew."
        subtitle="From a single window to your whole exterior — we handle every detail so your home looks its best year-round."
        center
      />

      <div style={{ display: 'grid', gridTemplateColumns: window.innerWidth >= 968 ? 'repeat(3, 1fr)' : window.innerWidth >= 640 ? 'repeat(2, 1fr)' : '1fr', gap: 20 }}>
        {SERVICES.map((s, i) => (
          <div key={s.id} style={{
            background: WHITE,
            border: `1px solid ${GRAY200}`,
            borderRadius: 18,
            padding: '2rem',
            transition: 'all 0.3s ease',
            cursor: 'pointer',
            position: 'relative',
            overflow: 'hidden'
          }} onMouseEnter={e => {
            e.currentTarget.style.transform = 'translateY(-6px)'
            e.currentTarget.style.boxShadow = '0 20px 40px rgba(15,28,63,0.12)'
            e.currentTarget.style.borderColor = BLUE
          }} onMouseLeave={e => {
            e.currentTarget.style.transform = 'translateY(0)'
            e.currentTarget.style.boxShadow = 'none'
            e.currentTarget.style.borderColor = GRAY200
          }}>
            <div style={{ fontSize: 38, marginBottom: 14 }}>{s.icon}</div>
            <div style={{ fontSize: 20, fontWeight: 700, color: NAVY, marginBottom: 8, letterSpacing: '-0.01em' }}>{s.title}</div>
            <div style={{ fontSize: 14, color: GRAY500, lineHeight: 1.6, marginBottom: 18 }}>{s.desc}</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
              {s.features.map(f => (
                <div key={f} style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 13, color: GRAY700 }}>
                  <div style={{ width: 16, height: 16, background: GREEN + '20', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                    <svg width="10" height="10" viewBox="0 0 24 24" fill={GREEN}><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/></svg>
                  </div>
                  {f}
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>

      <div style={{ textAlign: 'center', marginTop: 48 }}>
        <Btn primary large onClick={onCTA}>Get a Free Estimate →</Btn>
      </div>
    </Section>
  )
}

// ── Gallery / Before & After ──────────────────────────────────
function Gallery() {
  // Placeholder: replace `src` URLs with real before/after photos
  const items = [
    { label: 'Coventry Colonial — 32 windows' },
    { label: 'Storrs Ranch — gutter cleanout' },
    { label: 'Mansfield home — hard water removal' },
    { label: 'Tolland — solar panel restoration' },
  ]
  return (
    <Section bg={GRAY50}>
      <div id="gallery" />
      <SectionTitle eyebrow="Recent work" title="Before vs. after — every time." subtitle="Real jobs from real Coventry-area homes. The difference speaks for itself." center />
      <div style={{ display: 'grid', gridTemplateColumns: window.innerWidth >= 768 ? 'repeat(2, 1fr)' : '1fr', gap: 20 }}>
        {items.map((item, i) => (
          <div key={i} style={{
            background: WHITE,
            borderRadius: 16,
            overflow: 'hidden',
            border: `1px solid ${GRAY200}`,
            transition: 'all 0.3s',
          }} onMouseEnter={e => e.currentTarget.style.transform = 'scale(1.02)'} onMouseLeave={e => e.currentTarget.style.transform = 'scale(1)'}>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', aspectRatio: '2/1' }}>
              <div style={{ background: 'linear-gradient(135deg, #94a3b8 0%, #64748b 100%)', position: 'relative', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <span style={{ position: 'absolute', top: 12, left: 12, background: WHITE, color: GRAY700, padding: '4px 10px', borderRadius: 6, fontSize: 11, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.06em' }}>Before</span>
                <span style={{ fontSize: 48, opacity: 0.4 }}>📷</span>
              </div>
              <div style={{ background: `linear-gradient(135deg, #60a5fa 0%, #2563eb 100%)`, position: 'relative', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <span style={{ position: 'absolute', top: 12, left: 12, background: GREEN, color: WHITE, padding: '4px 10px', borderRadius: 6, fontSize: 11, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.06em' }}>After</span>
                <span style={{ fontSize: 48, opacity: 0.4 }}>✨</span>
              </div>
            </div>
            <div style={{ padding: '16px 20px', borderTop: `1px solid ${GRAY100}` }}>
              <div style={{ fontSize: 14, fontWeight: 600, color: NAVY }}>{item.label}</div>
            </div>
          </div>
        ))}
      </div>
      <div style={{ background: BLUE_LIGHT, border: `1px dashed ${BLUE}40`, borderRadius: 14, padding: '20px 24px', marginTop: 32, fontSize: 14, color: GRAY700, textAlign: 'center' }}>
        📸 <strong style={{ color: NAVY }}>Coming soon:</strong> Add real before/after photos in this section. Garrison — upload yours and I'll swap them in.
      </div>
    </Section>
  )
}

// ── Why Us ────────────────────────────────────────────────────
function WhyUs() {
  const reasons = [
    { icon: '🏡', title: 'Local & family-run', desc: 'Built in Coventry, owned by a UConn student. We treat your home like it\'s our own.' },
    { icon: '⚡', title: 'Show up on time', desc: 'No no-shows. No vague "between 9 and 3" windows. We confirm and arrive when we say.' },
    { icon: '🛡️', title: 'Insured & guaranteed', desc: 'Fully covered for peace of mind. If it\'s not spotless, we come back. No questions.' },
    { icon: '💸', title: 'Honest, fixed pricing', desc: 'Quotes upfront. No surprises. No upsell pressure. What we say is what you pay.' },
  ]
  return (
    <Section bg={NAVY} style={{ color: WHITE }}>
      <div style={{ display: 'grid', gridTemplateColumns: window.innerWidth >= 968 ? '1fr 1.4fr' : '1fr', gap: '3rem', alignItems: 'center' }}>
        <div>
          <div style={{ display: 'inline-block', background: 'rgba(255,255,255,0.1)', color: 'rgba(255,255,255,0.95)', padding: '6px 14px', borderRadius: 20, fontSize: 12, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: 14 }}>Why ClearView</div>
          <h2 style={{ fontFamily: "'Playfair Display', Georgia, serif", fontSize: 'clamp(28px, 4vw, 44px)', fontWeight: 800, lineHeight: 1.15, letterSpacing: '-0.02em', marginBottom: 16 }}>The window cleaners your neighbors actually recommend.</h2>
          <p style={{ fontSize: 17, color: 'rgba(255,255,255,0.7)', lineHeight: 1.6, marginBottom: 24 }}>We're not a national chain. We're a small, dedicated team that's earned our reputation one spotless home at a time.</p>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 16 }}>
          {reasons.map(r => (
            <div key={r.title} style={{ background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 14, padding: '1.5rem', backdropFilter: 'blur(10px)' }}>
              <div style={{ fontSize: 32, marginBottom: 10 }}>{r.icon}</div>
              <div style={{ fontSize: 16, fontWeight: 700, marginBottom: 6, color: WHITE }}>{r.title}</div>
              <div style={{ fontSize: 13, color: 'rgba(255,255,255,0.65)', lineHeight: 1.5 }}>{r.desc}</div>
            </div>
          ))}
        </div>
      </div>
    </Section>
  )
}

// ── Reviews ───────────────────────────────────────────────────
function Reviews() {
  return (
    <Section bg={WHITE}>
      <div id="reviews" />
      <SectionTitle eyebrow="Customer reviews" title="What our neighbors are saying" subtitle="Real reviews from real homeowners in Coventry and surrounding towns." center />
      <div style={{ display: 'grid', gridTemplateColumns: window.innerWidth >= 968 ? 'repeat(3, 1fr)' : '1fr', gap: 20 }}>
        {REVIEWS.map((r, i) => (
          <div key={i} style={{ background: GRAY50, borderRadius: 18, padding: '2rem', border: `1px solid ${GRAY200}` }}>
            <div style={{ display: 'flex', gap: 2, marginBottom: 16 }}>
              {[...Array(r.rating)].map((_, j) => <span key={j} style={{ color: '#fbbf24', fontSize: 18 }}>★</span>)}
            </div>
            <p style={{ fontSize: 15, color: GRAY700, lineHeight: 1.65, marginBottom: 20, fontStyle: 'italic' }}>"{r.text}"</p>
            <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
              <div style={{ width: 40, height: 40, borderRadius: '50%', background: `linear-gradient(135deg, ${BLUE} 0%, ${NAVY} 100%)`, color: WHITE, display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 700, fontSize: 14 }}>{r.name.charAt(0)}</div>
              <div>
                <div style={{ fontSize: 14, fontWeight: 700, color: NAVY }}>{r.name}</div>
                <div style={{ fontSize: 12, color: GRAY500 }}>{r.town}</div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </Section>
  )
}

// ── Service Area ──────────────────────────────────────────────
function ServiceArea() {
  return (
    <Section bg={GRAY50}>
      <div id="service-area" />
      <SectionTitle eyebrow="Service area" title="Proudly serving Coventry & surrounding towns" subtitle="Based in Coventry, CT. Free estimates throughout Tolland County and nearby." center />
      <div style={{ display: 'grid', gridTemplateColumns: window.innerWidth >= 768 ? 'repeat(5, 1fr)' : 'repeat(2, 1fr)', gap: 12, maxWidth: 900, margin: '0 auto' }}>
        {TOWNS.map(t => (
          <div key={t} style={{ background: WHITE, border: `1px solid ${GRAY200}`, borderRadius: 12, padding: '14px 16px', textAlign: 'center', fontSize: 14, fontWeight: 600, color: NAVY, transition: 'all 0.2s' }}
            onMouseEnter={e => { e.currentTarget.style.background = BLUE; e.currentTarget.style.color = WHITE; e.currentTarget.style.transform = 'translateY(-2px)' }}
            onMouseLeave={e => { e.currentTarget.style.background = WHITE; e.currentTarget.style.color = NAVY; e.currentTarget.style.transform = 'translateY(0)' }}>
            📍 {t}
          </div>
        ))}
      </div>
      <div style={{ textAlign: 'center', marginTop: 32, fontSize: 14, color: GRAY500 }}>
        Don't see your town? <a href="#quote" style={{ color: BLUE, fontWeight: 600 }}>Ask anyway</a> — we travel for the right job.
      </div>
    </Section>
  )
}

// ── Quote Form Modal ──────────────────────────────────────────
function QuoteModal({ open, onClose }) {
  const [form, setForm] = useState({
    name: '', phone: '', email: '', address: '',
    service: 'Window cleaning', preferred_date: '', notes: ''
  })
  const [submitting, setSubmitting] = useState(false)
  const [status, setStatus] = useState(null) // 'success' | 'error' | null

  const update = k => e => setForm(p => ({ ...p, [k]: e.target.value }))

  async function submit() {
    if (!form.name || !form.phone) {
      setStatus({ type: 'error', msg: 'Please enter your name and phone number.' })
      return
    }
    setSubmitting(true)
    setStatus(null)

    try {
      // Insert into leads table (same DB as CRM)
      const { error } = await supabase.from('leads').insert([{
        name: form.name,
        phone: form.phone,
        email: form.email || null,
        address: form.address || null,
        service: form.service,
        preferred_date: form.preferred_date || null,
        notes: form.notes || null,
        source: 'website',
        status: 'new'
      }])

      if (error) {
        console.error('Supabase error:', error)
        setStatus({ type: 'error', msg: 'Couldn\'t save your request. Please call us at ' + PHONE })
      } else {
        // Also post to Slack so Garrison gets notified instantly
        try {
          await fetch('/api/slack', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              text: `🌟 *New website lead!*\n*${form.name}* — ${form.phone}\nService: ${form.service}\nAddress: ${form.address || 'not provided'}\nPreferred date: ${form.preferred_date || 'flexible'}\nNotes: ${form.notes || 'none'}`
            })
          })
        } catch (e) {}
        setStatus({ type: 'success', msg: 'Got it! We\'ll text you within 24 hours.' })
        setTimeout(() => { onClose(); setStatus(null); setForm({ name: '', phone: '', email: '', address: '', service: 'Window cleaning', preferred_date: '', notes: '' }) }, 2500)
      }
    } catch (e) {
      console.error(e)
      setStatus({ type: 'error', msg: 'Something went wrong. Please call us at ' + PHONE })
    } finally {
      setSubmitting(false)
    }
  }

  if (!open) return null

  return (
    <div style={{ position: 'fixed', inset: 0, background: 'rgba(15,28,63,0.7)', backdropFilter: 'blur(8px)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 200, padding: 16 }} onClick={e => e.target === e.currentTarget && onClose()}>
      <div style={{ background: WHITE, borderRadius: 20, width: 540, maxWidth: '100%', maxHeight: '94vh', overflowY: 'auto', boxShadow: '0 32px 80px rgba(0,0,0,0.4)' }}>
        <div style={{ padding: '2rem 2rem 1rem', borderBottom: `1px solid ${GRAY100}` }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
            <div>
              <div style={{ fontSize: 12, color: BLUE, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: 6 }}>Get a free quote</div>
              <h3 style={{ fontFamily: "'Playfair Display', Georgia, serif", fontSize: 26, fontWeight: 800, color: NAVY, lineHeight: 1.2, letterSpacing: '-0.02em' }}>Tell us about your home</h3>
              <p style={{ fontSize: 14, color: GRAY500, marginTop: 6 }}>We'll text you back within 24 hours with a free estimate.</p>
            </div>
            <button onClick={onClose} style={{ background: 'none', border: 'none', fontSize: 24, color: GRAY500, cursor: 'pointer', padding: 4, lineHeight: 1 }}>×</button>
          </div>
        </div>

        <div style={{ padding: '1.5rem 2rem 2rem' }}>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
            <Field label="Your name *" value={form.name} onChange={update('name')} placeholder="Jane Smith" />
            <Field label="Phone *" value={form.phone} onChange={update('phone')} placeholder="860-000-0000" type="tel" />
            <Field label="Email" value={form.email} onChange={update('email')} placeholder="you@email.com" type="email" full />
            <Field label="Home address" value={form.address} onChange={update('address')} placeholder="123 Main St, Coventry CT" full />
            <div style={{ gridColumn: '1 / -1' }}>
              <label style={{ fontSize: 12, color: GRAY500, fontWeight: 600, display: 'block', marginBottom: 6, textTransform: 'uppercase', letterSpacing: '0.05em' }}>Service</label>
              <select value={form.service} onChange={update('service')} style={{ background: GRAY50, border: `1.5px solid ${GRAY200}`, borderRadius: 10, padding: '11px 14px', color: GRAY900, fontSize: 14, width: '100%', outline: 'none' }}>
                {SERVICES.map(s => <option key={s.id} value={s.title}>{s.title}</option>)}
                <option value="Multiple / not sure">Multiple services / not sure yet</option>
              </select>
            </div>
            <Field label="Preferred date" value={form.preferred_date} onChange={update('preferred_date')} type="date" full />
            <div style={{ gridColumn: '1 / -1' }}>
              <label style={{ fontSize: 12, color: GRAY500, fontWeight: 600, display: 'block', marginBottom: 6, textTransform: 'uppercase', letterSpacing: '0.05em' }}>Anything else?</label>
              <textarea value={form.notes} onChange={update('notes')} placeholder="Approximate window count, special requests, gate code, etc." style={{ background: GRAY50, border: `1.5px solid ${GRAY200}`, borderRadius: 10, padding: '11px 14px', color: GRAY900, fontSize: 14, width: '100%', minHeight: 80, outline: 'none', resize: 'vertical', fontFamily: 'inherit' }} />
            </div>
          </div>

          {status && (
            <div style={{ marginTop: 18, padding: '12px 16px', borderRadius: 10, background: status.type === 'success' ? '#f0fdf4' : '#fef2f2', color: status.type === 'success' ? GREEN : '#dc2626', fontSize: 14, fontWeight: 600, border: `1px solid ${status.type === 'success' ? GREEN : '#dc2626'}30` }}>
              {status.type === 'success' ? '✓ ' : '⚠ '}{status.msg}
            </div>
          )}

          <button onClick={submit} disabled={submitting} style={{ width: '100%', marginTop: 20, background: submitting ? GRAY500 : `linear-gradient(135deg, #1d4ed8 0%, ${BLUE} 100%)`, border: 'none', color: WHITE, borderRadius: 12, padding: '14px', fontSize: 15, fontWeight: 800, cursor: submitting ? 'wait' : 'pointer', boxShadow: '0 4px 14px rgba(37,99,235,0.35)' }}>
            {submitting ? 'Sending...' : 'Request Free Estimate →'}
          </button>

          <div style={{ marginTop: 14, fontSize: 12, color: GRAY500, textAlign: 'center' }}>
            Or call us directly: <a href={PHONE_TEL} style={{ color: BLUE, fontWeight: 700 }}>{PHONE}</a>
          </div>
        </div>
      </div>
    </div>
  )
}

function Field({ label, value, onChange, placeholder, type = 'text', full }) {
  return (
    <div style={{ gridColumn: full ? '1 / -1' : undefined }}>
      <label style={{ fontSize: 12, color: GRAY500, fontWeight: 600, display: 'block', marginBottom: 6, textTransform: 'uppercase', letterSpacing: '0.05em' }}>{label}</label>
      <input type={type} value={value} onChange={onChange} placeholder={placeholder} style={{ background: GRAY50, border: `1.5px solid ${GRAY200}`, borderRadius: 10, padding: '11px 14px', color: GRAY900, fontSize: 14, width: '100%', outline: 'none', transition: 'border-color 0.2s' }}
        onFocus={e => e.target.style.borderColor = BLUE}
        onBlur={e => e.target.style.borderColor = GRAY200} />
    </div>
  )
}

// ── Final CTA ─────────────────────────────────────────────────
function FinalCTA({ onCTA }) {
  return (
    <Section bg={WHITE} style={{ padding: '6rem 1.5rem' }}>
      <div style={{ background: `linear-gradient(135deg, ${NAVY_DARK} 0%, ${NAVY} 50%, #1e3a6e 100%)`, borderRadius: 24, padding: window.innerWidth >= 768 ? '4rem 3rem' : '3rem 1.5rem', color: WHITE, textAlign: 'center', position: 'relative', overflow: 'hidden' }}>
        <div style={{ position: 'absolute', top: '-30%', right: '-15%', width: '50%', height: '160%', borderRadius: '50%', background: 'rgba(59,130,246,0.2)', filter: 'blur(60px)' }} />
        <div style={{ position: 'relative', zIndex: 2 }}>
          <h2 style={{ fontFamily: "'Playfair Display', Georgia, serif", fontSize: 'clamp(28px, 5vw, 48px)', fontWeight: 800, lineHeight: 1.1, letterSpacing: '-0.02em', marginBottom: 16 }}>Ready for spotless windows?</h2>
          <p style={{ fontSize: 18, color: 'rgba(255,255,255,0.75)', maxWidth: 560, margin: '0 auto 32px', lineHeight: 1.6 }}>Free estimates. No pressure. Just clean windows and a job done right.</p>
          <div style={{ display: 'flex', gap: 12, justifyContent: 'center', flexWrap: 'wrap' }}>
            <Btn primary large onClick={onCTA}>Get Free Quote →</Btn>
            <Btn large href={PHONE_TEL} style={{ background: 'rgba(255,255,255,0.1)', border: '2px solid rgba(255,255,255,0.25)', color: WHITE, backdropFilter: 'blur(10px)' }}>📞 {PHONE}</Btn>
          </div>
        </div>
      </div>
    </Section>
  )
}

// ── Footer ────────────────────────────────────────────────────
function Footer() {
  return (
    <footer style={{ background: NAVY_DARK, color: 'rgba(255,255,255,0.7)', padding: '3rem 1.5rem 2rem' }}>
      <div style={{ maxWidth: 1200, margin: '0 auto' }}>
        <div style={{ display: 'grid', gridTemplateColumns: window.innerWidth >= 768 ? '1.5fr 1fr 1fr 1fr' : '1fr', gap: '2rem', marginBottom: '2.5rem' }}>
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 14 }}>
              <div style={{ width: 38, height: 38, background: `linear-gradient(135deg, #1d4ed8 0%, #3b82f6 100%)`, borderRadius: 10, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <svg width="20" height="20" viewBox="0 0 24 24" fill="white"><path d="M3 13h1v7c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2v-7h1c.55 0 1-.45 1-1s-.45-1-1-1L12 2 2 11c-.55 0-1 .45-1 1s.45 1 1 1z"/></svg>
              </div>
              <div>
                <div style={{ fontSize: 17, fontWeight: 800, color: WHITE, letterSpacing: '-0.02em' }}>ClearView Windows</div>
                <div style={{ fontSize: 10, color: 'rgba(255,255,255,0.5)', textTransform: 'uppercase', letterSpacing: '0.1em', marginTop: -2 }}>Connecticut</div>
              </div>
            </div>
            <p style={{ fontSize: 13, lineHeight: 1.6, maxWidth: 320 }}>Professional window cleaning in Coventry, CT and surrounding towns. Locally owned. Insured. Five-star rated.</p>
          </div>
          <div>
            <div style={{ fontSize: 12, color: WHITE, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 14 }}>Services</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              {SERVICES.slice(0, 6).map(s => <a key={s.id} href="#services" style={{ fontSize: 13, color: 'rgba(255,255,255,0.6)' }}>{s.title}</a>)}
            </div>
          </div>
          <div>
            <div style={{ fontSize: 12, color: WHITE, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 14 }}>Service Area</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              {TOWNS.slice(0, 6).map(t => <span key={t} style={{ fontSize: 13, color: 'rgba(255,255,255,0.6)' }}>{t}, CT</span>)}
            </div>
          </div>
          <div>
            <div style={{ fontSize: 12, color: WHITE, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 14 }}>Contact</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              <a href={PHONE_TEL} style={{ fontSize: 14, color: WHITE, fontWeight: 600 }}>📞 {PHONE}</a>
              <a href={`mailto:${EMAIL}`} style={{ fontSize: 13, color: 'rgba(255,255,255,0.6)' }}>✉ {EMAIL}</a>
              <span style={{ fontSize: 13, color: 'rgba(255,255,255,0.6)' }}>📍 Coventry, CT</span>
            </div>
          </div>
        </div>
        <div style={{ borderTop: '1px solid rgba(255,255,255,0.1)', paddingTop: '1.5rem', display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 12 }}>
          <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.4)' }}>© 2026 ClearView Windows. All rights reserved.</div>
          <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.4)' }}>Licensed & Insured · Coventry, CT</div>
        </div>
      </div>
    </footer>
  )
}

// ── Main App ──────────────────────────────────────────────────
export default function App() {
  const [quoteOpen, setQuoteOpen] = useState(false)

  // Close modal on Esc
  useEffect(() => {
    const handler = e => { if (e.key === 'Escape') setQuoteOpen(false) }
    window.addEventListener('keydown', handler)
    return () => window.removeEventListener('keydown', handler)
  }, [])

  return (
    <>
      <Nav onCTA={() => setQuoteOpen(true)} />
      <Hero onCTA={() => setQuoteOpen(true)} />
      <Services onCTA={() => setQuoteOpen(true)} />
      <Gallery />
      <WhyUs />
      <Reviews />
      <ServiceArea />
      <FinalCTA onCTA={() => setQuoteOpen(true)} />
      <Footer />
      <QuoteModal open={quoteOpen} onClose={() => setQuoteOpen(false)} />
    </>
  )
}
