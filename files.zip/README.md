# ClearView Windows Website

Lead-capture website for ClearView Windows. Built with React + Vite. Hosted on Vercel.

## Setup (one time)

### 1. Add your Supabase anon key
Open `src/supabase.js` and replace `REPLACE_WITH_YOUR_ANON_KEY` with your real anon key.

Get it from: Supabase dashboard → Project Settings → API → `anon` `public` key.

It's safe to commit this — it's a public key.

### 2. Create the leads table (if it doesn't already have these columns)
Run this in Supabase SQL editor:

```sql
ALTER TABLE leads ADD COLUMN IF NOT EXISTS source text DEFAULT 'manual';
ALTER TABLE leads ADD COLUMN IF NOT EXISTS preferred_date date;
ALTER TABLE leads ADD COLUMN IF NOT EXISTS service text;
```

### 3. Set up RLS for public lead submissions
The website needs to write to `leads` without authentication. Run this:

```sql
-- Allow anonymous inserts to leads (so the website can submit them)
CREATE POLICY "Allow public lead submissions"
ON leads FOR INSERT
TO anon
WITH CHECK (true);
```

## Deploy to Vercel

1. Create new GitHub repo (e.g., `clearview-website`)
2. Push these files to that repo
3. Go to vercel.com → New Project → Import the repo
4. Vercel auto-detects Vite. Click Deploy.
5. Your site is live at `clearview-website.vercel.app`

## Add custom domain later

1. Buy `clearviewwindowsct.com` from Namecheap (~$10/year)
2. In Vercel: Project → Settings → Domains → Add → enter the domain
3. Vercel shows you DNS records to add at Namecheap
4. Done.

## Project structure

- `src/App.jsx` — the whole website (all sections in one file for simplicity)
- `src/supabase.js` — connection to your CRM database
- `api/slack.js` — serverless function for Slack lead notifications
- `index.html` — meta tags + SEO

## Things you'll want to update

- Add real before/after photos to the Gallery section (search "Coming soon" in App.jsx)
- Update the placeholder reviews with real Google reviews once you have them
- Adjust the EMAIL constant in App.jsx
