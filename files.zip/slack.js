// Vercel serverless function — forwards lead notifications to Slack
export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' })
  }

  const SLACK_WEBHOOK = 'https://hooks.slack.com/services/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'

  try {
    const response = await fetch(SLACK_WEBHOOK, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(req.body)
    })

    if (!response.ok) {
      throw new Error('Slack returned ' + response.status)
    }

    return res.status(200).json({ ok: true })
  } catch (err) {
    console.error('Slack notification failed:', err)
    return res.status(500).json({ error: 'Failed to send notification' })
  }
}
