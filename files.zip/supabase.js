import { createClient } from '@supabase/supabase-js'

const SUPABASE_URL = 'https://xenmysvxfydcbyrlwlfm.supabase.co'
// This is the public anon key — safe to expose
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inhlbm15c3Z4ZnlkY2J5cmx3bGZtIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzgzNTExMjIsImV4cCI6MjA5MzkyNzEyMn0.KkloIssWfOnvMDRZ0h4CsvK5--QsA1iA_luTH5Pg_PI'

export const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY)
